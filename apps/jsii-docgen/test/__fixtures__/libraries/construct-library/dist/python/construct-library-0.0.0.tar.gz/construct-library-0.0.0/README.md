# construct-library

This is a test project to make sure the `jsii-docgen` cli property renders API documentation
for construct libraries.

import json
import setuptools

kwargs = json.loads(
    """
{
    "name": "construct-library",
    "version": "0.0.0",
    "description": "construct-library",
    "license": "Apache-2.0",
    "url": "https://dummy.com",
    "long_description_content_type": "text/markdown",
    "author": "dummy<dummy@example.com>",
    "bdist_wheel": {
        "universal": true
    },
    "project_urls": {
        "Source": "https://dummy.com"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "construct_library",
        "construct_library._jsii",
        "construct_library.submod1"
    ],
    "package_data": {
        "construct_library._jsii": [
            "construct-library@0.0.0.jsii.tgz"
        ],
        "construct_library": [
            "py.typed"
        ]
    },
    "python_requires": "~=3.7",
    "install_requires": [
        "aws-cdk.aws-events>=1.110.1, <2.0.0",
        "aws-cdk.aws-iam>=1.110.1, <2.0.0",
        "aws-cdk.aws-kms>=1.110.1, <2.0.0",
        "aws-cdk.aws-s3>=1.110.1, <2.0.0",
        "aws-cdk.cloud-assembly-schema>=1.110.1, <2.0.0",
        "aws-cdk.core>=1.110.1, <2.0.0",
        "constructs>=3.3.69, <4.0.0",
        "jsii>=1.84.0, <2.0.0",
        "publication>=0.0.3",
        "typeguard~=2.13.3"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Typing :: Typed",
        "License :: OSI Approved"
    ],
    "scripts": []
}
"""
)

with open("README.md", encoding="utf8") as fp:
    kwargs["long_description"] = fp.read()


setuptools.setup(**kwargs)
